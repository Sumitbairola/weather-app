import React from 'react';

const CityName = ({ name }) => {
  return (
    <h2 className="city-name">{name}</h2>
  );
};

export default CityName;
